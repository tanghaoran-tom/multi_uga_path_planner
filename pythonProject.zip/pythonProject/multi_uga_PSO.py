import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import numpy as np
from scipy.interpolate import interp1d

# 使用线性插值生成更多路径点
def interpolate_path(path, num_interp_points=100):
    x = path[:, 0]
    y = path[:, 1]
    z = path[:, 2]

    # 在每个轴上分别进行插值
    interp_x = np.linspace(x.min(), x.max(), num_interp_points)
    interp_y = np.linspace(y.min(), y.max(), num_interp_points)
    interp_z = np.linspace(z.min(), z.max(), num_interp_points)

    # 线性插值函数
    f_x = interp1d(np.linspace(0, 1, len(x)), x, kind='linear')
    f_y = interp1d(np.linspace(0, 1, len(y)), y, kind='linear')
    f_z = interp1d(np.linspace(0, 1, len(z)), z, kind='linear')

    # 生成插值后的路径
    interp_path = np.vstack((f_x(np.linspace(0, 1, num_interp_points)),
                             f_y(np.linspace(0, 1, num_interp_points)),
                             f_z(np.linspace(0, 1, num_interp_points)))).T
    return interp_path


# 1. 定义地形生成函数
def generate_terrain(x, y, peaks):
    z = np.zeros_like(x)
    for peak in peaks:
        xc, yc = peak["center"]
        x_decay, y_decay = peak["decay"]
        height = peak["height"]
        z += height * np.exp(-((x - xc) / x_decay)**2 - ((y - yc) / y_decay)**2)
    return z

# 2. 定义雷达威胁模型
def radar_threat(x, y, z, radars, R_min, R_max):
    threat = np.zeros_like(x)
    for radar in radars:
        xc, yc, zc = radar["center"]
        distance = np.sqrt((x - xc)**2 + (y - yc)**2 + (z - zc)**2)
        threat += np.where(distance <= R_max, np.exp(-distance / R_min), 0)
    return threat

# 检测路径是否与地形或禁飞区冲突
def collision_detection(path, terrain, no_fly_zones):
    num_points = 100
    segment_points = np.linspace(0, 1, num_points)[:, None]
    all_segments = path[:-1, None, :] * (1 - segment_points) + path[1:, None, :] * segment_points

    x_vals = np.clip(all_segments[..., 0].ravel(), 0, terrain.shape[0] - 1).astype(int)
    y_vals = np.clip(all_segments[..., 1].ravel(), 0, terrain.shape[1] - 1).astype(int)
    z_vals = all_segments[..., 2].ravel()

    # 地形高度检测
    terrain_heights = terrain[x_vals, y_vals]
    if np.any(z_vals < terrain_heights):
        return True

    # 禁飞区检测
    for zone in no_fly_zones:
        center = np.array(zone["center"][:2])
        radius = zone["radius"]
        height_min, height_max = zone["height_range"]

        positions_2d = all_segments[..., :2].reshape(-1, 2)
        distances = np.linalg.norm(positions_2d - center, axis=1)
        in_radius = distances <= radius
        in_height = (z_vals >= height_min) & (z_vals <= height_max)

        if np.any(in_radius & in_height):
            return True

    return False

# 适应度函数
def fitness_function(path, terrain, radars, k1, k2, k3, R_min, R_max):
    # 检查路径是否与地形发生碰撞
    if collision_detection(path, terrain):
        return 999  # 如果路径发生碰撞，返回无穷大的代价

   # 使用插值生成更多路径点
    interpolated_path = interpolate_path(path)

    # 路径长度代价
    fL = np.sum(np.sqrt(np.sum(np.diff(interpolated_path, axis=0)**2, axis=1)))
    fL_max = 200  # 根据地图的最大可能路径长度估计
    fL_min = 0
    fL_normalized = (fL - fL_min) / (fL_max - fL_min)

    # 雷达威胁代价
    fW = np.sum(radar_threat(interpolated_path[:, 0], interpolated_path[:, 1], interpolated_path[:, 2], radars, R_min, R_max))
    fW_max = 100  # 根据雷达分布和路径点数量合理估计
    fW_min = 0
    fW_normalized = (fW - fW_min) / (fW_max - fW_min)

    # 偏航角代价
    yaw_diff = np.diff(np.arctan2(np.diff(interpolated_path[:, 1]), np.diff(interpolated_path[:, 0])))
    fA = np.sum(np.abs(yaw_diff))
    fA_max = np.pi  # 最大偏航角为 180 度
    fA_min = 0
    fA_normalized = (fA - fA_min) / (fA_max - fA_min)

    # 综合代价
    return k1 * fL_normalized + k2 * fW_normalized + k3 * fA_normalized

# 5. 绘制结果
def plot_results(terrain, path, radars, start, end, num_interp_points=100):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    x, y = np.meshgrid(np.arange(terrain.shape[0]), np.arange(terrain.shape[1]))
    ax.plot_surface(x, y, terrain, alpha=0.7, cmap='terrain')

    # 绘制雷达
    for radar in radars:
        xc, yc, zc = radar["center"]
        ax.scatter(xc, yc, zc, color='red', s=50, label="Radar")

    # 绘制起点和终点
    ax.scatter(*start, color='green', s=100, label="Start", marker="o")
    ax.scatter(*end, color='blue', s=100, label="End", marker="x")

    # 绘制原始路径
    ax.plot(path[:, 0], path[:, 1], path[:, 2], color='blue', label="Original Path", linestyle='-', linewidth=2)

    # 使用插值生成平滑路径
    interpolated_path = interpolate_path(path, num_interp_points)
    ax.plot(interpolated_path[:, 0], interpolated_path[:, 1], interpolated_path[:, 2], color='orange', label="Interpolated Path", linestyle='--', linewidth=2)

    plt.legend()
    plt.show()


import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.interpolate import interp1d


# 使用线性插值生成更多路径点
def interpolate_path(path, num_interp_points=100):
    x = path[:, 0]
    y = path[:, 1]
    z = path[:, 2]

    f_x = interp1d(np.linspace(0, 1, len(x)), x, kind='linear')
    f_y = interp1d(np.linspace(0, 1, len(y)), y, kind='linear')
    f_z = interp1d(np.linspace(0, 1, len(z)), z, kind='linear')

    interp_path = np.vstack((f_x(np.linspace(0, 1, num_interp_points)),
                             f_y(np.linspace(0, 1, num_interp_points)),
                             f_z(np.linspace(0, 1, num_interp_points)))).T
    return interp_path


# 地形生成函数
# 创建地形的函数
def generate_terrain(x, y, peaks):
    terrain = np.zeros_like(x)
    for peak in peaks:
        cx, cy = peak["center"]
        dx, dy = peak["decay"]
        height = peak["height"]
        terrain += height * np.exp(-(((x - cx) / dx) ** 2 + ((y - cy) / dy) ** 2))

    return terrain


# 雷达威胁模型
def radar_threat(x, y, z, radars, R_min, R_max):
    threat = np.zeros_like(x)
    for radar in radars:
        xc, yc, zc = radar["center"]
        distance = np.sqrt((x - xc) ** 2 + (y - yc) ** 2 + (z - zc) ** 2)
        threat += np.where(distance <= R_max, np.exp(-distance / R_min), 0)
    return threat


# 碰撞检测
# 检测路径是否与地形或禁飞区冲突
def collision_detection(path, terrain, no_fly_zones):
    num_points = 100
    segment_points = np.linspace(0, 1, num_points)[:, None]
    all_segments = path[:-1, None, :] * (1 - segment_points) + path[1:, None, :] * segment_points

    x_vals = np.clip(all_segments[..., 0].ravel(), 0, terrain.shape[0] - 1).astype(int)
    y_vals = np.clip(all_segments[..., 1].ravel(), 0, terrain.shape[1] - 1).astype(int)
    z_vals = all_segments[..., 2].ravel()

    # 地形高度检测
    terrain_heights = terrain[x_vals, y_vals]
    if np.any(z_vals < terrain_heights):
        return True

    # 禁飞区检测
    for zone in no_fly_zones:
        center = np.array(zone["center"][:2])
        radius = zone["radius"]
        height_min, height_max = zone["height_range"]

        positions_2d = all_segments[..., :2].reshape(-1, 2)
        distances = np.linalg.norm(positions_2d - center, axis=1)
        in_radius = distances <= radius
        in_height = (z_vals >= height_min) & (z_vals <= height_max)

        if np.any(in_radius & in_height):
            return True

    return False

def get_terrain_along_path(terrain, path):
    terrain_height = []
    max_x, max_y = terrain.shape
    for p in path:
        x = int(np.clip(p[0], 0, max_x - 1))  # 限制 X 坐标
        y = int(np.clip(p[1], 0, max_y - 1))  # 限制 Y 坐标
        terrain_height.append(terrain[x, y])
    return terrain_height

# 适应度函数
def fitness_function(path, terrain, radars, k1, k2, k3, R_min, R_max):
    if collision_detection(path, terrain,no_fly_zones):
        return 1e6 

    interpolated_path = interpolate_path(path)
    fL = np.sum(np.sqrt(np.sum(np.diff(interpolated_path, axis=0) ** 2, axis=1)))
    fL_normalized = fL / 200
    fW = np.sum(
        radar_threat(interpolated_path[:, 0], interpolated_path[:, 1], interpolated_path[:, 2], radars, R_min, R_max))
    fW_normalized = fW / 100
    yaw_diff = np.diff(np.arctan2(np.diff(interpolated_path[:, 1]), np.diff(interpolated_path[:, 0])))
    fA = np.sum(np.abs(yaw_diff))
    fA_normalized = fA / np.pi
    sum = k1 * fL_normalized + k2 * fW_normalized + k3 * fA_normalized
    return sum


# 粒子群优化
class PSO:
    def __init__(self, num_particles, num_points, bounds, fitness_func, max_iter, C1, C2, W_max, W_min, V_max):
        self.num_particles = num_particles
        self.num_points = num_points
        self.bounds = bounds
        self.fitness_func = fitness_func
        self.max_iter = max_iter
        self.C1 = C1
        self.C2 = C2
        self.W_max = W_max
        self.W_min = W_min
        self.V_max = V_max
        self.initialize_particles()

    def initialize_particles(self):
        self.positions = np.random.uniform(self.bounds[:, 0], self.bounds[:, 1],
                                           (self.num_particles, self.num_points, 3))
        self.velocities = np.random.uniform(-self.V_max, self.V_max, (self.num_particles, self.num_points, 3))
        self.pbest = self.positions.copy()
        self.pbest_scores = np.full(self.num_particles, np.inf)
        self.gbest = None
        self.gbest_score = np.inf

    def optimize(self, start, end):
        for t in range(self.max_iter):
            W = self.W_max - t * (self.W_max - self.W_min) / self.max_iter
            for i in range(self.num_particles):
                self.positions[i, 0, :] = start
                self.positions[i, -1, :] = end
                score = self.fitness_func(self.positions[i])
                if score < self.pbest_scores[i]:
                    self.pbest_scores[i] = score
                    self.pbest[i] = self.positions[i].copy()
                if score < self.gbest_score:
                    self.gbest_score = score
                    self.gbest = self.positions[i].copy()
                r1, r2 = np.random.rand(2)
                self.velocities[i] = W * self.velocities[i] + \
                                     self.C1 * r1 * (self.pbest[i] - self.positions[i]) + \
                                     self.C2 * r2 * (self.gbest - self.positions[i])
                self.velocities[i] = np.clip(self.velocities[i], -self.V_max, self.V_max)
                self.positions[i] += self.velocities[i]
                self.positions[i] = np.clip(self.positions[i], self.bounds[:, 0], self.bounds[:, 1])
        return self.gbest



# 生成分散的起始点
def generate_distributed_points(num_points, x_range, y_range, z_range):
    points = []
    for _ in range(num_points):
        x = np.random.uniform(*x_range)
        y = np.random.uniform(*y_range)
        z = np.random.uniform(*z_range)  # 起始点在空中
        points.append(np.array([x, y, z]))
    return points

# 生成集中分布的终点
def generate_clustered_points(num_points, center, radius, z_range):
    points = []
    for _ in range(num_points):
        x = np.random.normal(center[0], radius)
        y = np.random.normal(center[1], radius)
        z = np.random.uniform(*z_range)  # 终点在地面
        points.append(np.clip([x, y, z], [0, 0, z_range[0]], [100, 100, z_range[1]]))  # 限制在范围内
    return points


# 绘制所有无人机的高度与地形的对比折线图
def plot_combined(paths, terrain, radars, no_fly_zones, starts, ends, num_interp_points=100):
    # 创建一个图窗，包含两个子图
    fig = plt.figure(figsize=(16, 8))

    # 第一个子图：综合地形高度折线图
    ax1 = fig.add_subplot(121)
    from matplotlib import colormaps
    colors = colormaps["tab10"]  # 使用Tab10配色方案

    for i, path in enumerate(paths):
        # 为每个无人机路径分配颜色
        color = colors(i)

        # 初始化综合地形高度
        combined_terrain_height = []

        for point in path:
            x, y, z_drone = point
            x_idx, y_idx = int(round(x)), int(round(y))

            # 确保索引在地形范围内
            x_idx = np.clip(x_idx, 0, terrain.shape[0] - 1)
            y_idx = np.clip(y_idx, 0, terrain.shape[1] - 1)

            # 默认高度为地形高度
            z_terrain = terrain[x_idx, y_idx]
            z_combined = z_terrain


            # 检查禁飞区
            for zone in no_fly_zones:
                # print(np.shape(zone))
                xc, yc, _ = zone["center"]

                radius = zone["radius"]
                z_min, z_max = zone["height_range"]
                if (x - xc) ** 2 + (y - yc) ** 2 <= radius ** 2:
                    z_combined = max(z_combined, z_min)  # 取禁飞区的最低高度

            # 检查雷达覆盖范围
            for radar in radars:
                xc, yc, zc = radar["center"]
                radius = radar["radius"]
                if (x - xc) ** 2 + (y - yc) ** 2 + (z_drone - zc) ** 2 <= radius ** 2:
                    z_radar_surface = zc + np.sqrt(radius ** 2 - (x - xc) ** 2 - (y - yc) ** 2)
                    z_combined = max(z_combined, z_radar_surface)  # 取雷达表面的最高高度

            combined_terrain_height.append(z_combined)

        # 绘制无人机路径高度
        ax1.plot(
            range(len(path)),
            path[:, 2],
            label=f"Drone {i + 1} Height",
            linestyle='-',
            marker='o',
            color=color
        )

        # 绘制综合地形高度
        ax1.plot(
            range(len(path)),
            combined_terrain_height,
            label=f"Combined Terrain {i + 1}",
            linestyle='--',
            color=color
        )

    ax1.set_title("Drones Height vs Combined Terrain")
    ax1.set_xlabel("Path Index")
    ax1.set_ylabel("Height")
    ax1.legend()
    ax1.grid()

    # 第二个子图：三维地形与路径
    ax2 = fig.add_subplot(122, projection='3d')

    # 地形表面
    x, y = np.meshgrid(np.arange(terrain.shape[0]), np.arange(terrain.shape[1]))
    ax2.plot_surface(x, y, terrain, alpha=0.7, cmap='terrain')

    # 绘制雷达覆盖范围（半圆球）
    for radar in radars:
        xc, yc, zc = radar["center"]
        radius = radar["radius"]
        u = np.linspace(0, np.pi, 50)  # 半球
        v = np.linspace(0, 2 * np.pi, 50)
        x_sphere = xc + radius * np.outer(np.sin(u), np.cos(v))
        y_sphere = yc + radius * np.outer(np.sin(u), np.sin(v))
        z_sphere = zc + radius * np.outer(np.cos(u), np.ones_like(v))
        ax2.plot_surface(x_sphere, y_sphere, z_sphere, color='red', alpha=0.3)

    # 绘制禁飞区（圆柱体）
    for zone in no_fly_zones:
        xc, yc, z_min, z_max = zone["center"][0], zone["center"][1], zone["height_range"][0], zone["height_range"][1]
        radius = zone["radius"]

        # 圆柱体参数
        theta = np.linspace(0, 2 * np.pi, 50)
        z = np.linspace(z_min, z_max, 50)
        theta_grid, z_grid = np.meshgrid(theta, z)
        x_cylinder = xc + radius * np.cos(theta_grid)
        y_cylinder = yc + radius * np.sin(theta_grid)

        # 绘制禁飞区
        ax2.plot_surface(
            x_cylinder, y_cylinder, z_grid,
            color='orange', alpha=0.5, rstride=10, cstride=10
        )

    for i, (start, end, path) in enumerate(zip(starts, ends, paths)):
        color = colors(i)

        # 绘制起点、终点
        ax2.scatter(*start, color=color, s=100, label=f"Start {i + 1}", marker="o")
        ax2.scatter(*end, color=color, s=100, label=f"End {i + 1}", marker="x")

        # 路径绘制
        ax2.plot(path[:, 0], path[:, 1], path[:, 2], color=color, label=f"Path {i + 1}", linewidth=2)

        # 绘制综合地形高度线
        interpolated_path = interpolate_path(path, num_interp_points)
        combined_height = []

        for p in interpolated_path:
            x, y = p[0], p[1]
            x_idx, y_idx = int(round(x)), int(round(y))
            x_idx = np.clip(x_idx, 0, terrain.shape[0] - 1)
            y_idx = np.clip(y_idx, 0, terrain.shape[1] - 1)
            z_combined = terrain[x_idx, y_idx]

            # 添加禁飞区或雷达覆盖范围的高度
            for zone in no_fly_zones:
                xc, yc,_ = zone["center"]
                radius = zone["radius"]
                if (x - xc) ** 2 + (y - yc) ** 2 <= radius ** 2:
                    z_combined = max(z_combined, zone["height_range"][0])

            for radar in radars:
                xc, yc, zc = radar["center"]
                radius = radar["radius"]
                if (x - xc) ** 2 + (y - yc) ** 2 <= radius ** 2:
                    z_radar_surface = zc + np.sqrt(radius ** 2 - (x - xc) ** 2 - (y - yc) ** 2)
                    z_combined = max(z_combined, z_radar_surface)

            combined_height.append(z_combined)

        ax2.plot(interpolated_path[:, 0], interpolated_path[:, 1], combined_height,
                 color=color, linestyle='--', linewidth=1.5, alpha=0.7)

    ax2.set_title("3D Terrain and Drone Paths")
    ax2.set_xlabel("X-axis")
    ax2.set_ylabel("Y-axis")
    ax2.set_zlabel("Z-axis")
    ax2.legend()

    # 调整布局并显示
    plt.tight_layout()
    plt.show()

# 主程序
if __name__ == "__main__":
    # 增加复杂地形的 peaks 配置
    peaks = [
        {"center": (30, 30), "decay": (4, 6), "height": 50},  # 左侧陡峭山峰
        {"center": (70, 70), "decay": (6, 4), "height": 50},  # 右侧陡峭山峰
        {"center": (50, 50), "decay": (8, 8), "height": 100},  # 中心高山
        {"center": (30, 70), "decay": (5, 7), "height": 30},  # 额外小山峰
        {"center": (70, 30), "decay": (7, 5), "height": 30}  # 对称小山峰
    ]

    radars = [
        {"center": (80, 30, 0), "radius": 15},  # 增大雷达范围
        {"center": (30, 80, 0), "radius": 15}
    ]

    bounds = np.array([[0, 100], [0, 100], [0, 100]])

    no_fly_zones = [
        {"center": (40, 40, 0), "radius": 10, "height_range": (0, 60)},  # 圆柱禁飞区
        {"center": (60, 60, 0), "radius": 12, "height_range": (20, 80)}
    ]

    # 参数
    num_drones = 5
    x_range_start = (0, 3)  # 起点X坐标范围
    y_range_start = (80, 100) # 起点Y坐标范围
    z_range_start = (20, 24)  # 起点Z坐标范围（空中）

    cluster_center = [80, 0]  # 终点集中点的中心
    cluster_radius = 30 # 终点集中点的半径
    z_range_end = (0, 2)  # 终点Z坐标范围（地面）

    # 生成起点和终点
    starts = generate_distributed_points(num_drones, x_range_start, y_range_start, z_range_start)
    ends = generate_clustered_points(num_drones, cluster_center, cluster_radius, z_range_end)

    k1, k2, k3 = 0.5, 0.3, 0.2

    x = np.linspace(0, 100, 100)
    y = np.linspace(0, 100, 100)
    x, y = np.meshgrid(x, y)
    terrain = generate_terrain(x, y, peaks)

    fitness_func = lambda path: fitness_function(path, terrain, radars, k1, k2, k3, 20, 30)
    paths = []
    print("处理中……")

    for start, end in zip(starts, ends):
        pso = PSO(
            num_particles=30,  # 增加粒子数量
            num_points=5,
            bounds=bounds,
            fitness_func=fitness_func,
            max_iter=200,  # 增加迭代次数
            C1=2.0,  # 增大历史学习因子
            C2=2.0,  # 增大全局学习因子
            W_max=0.7,  # 降低惯性权重范围
            W_min=0.3,
            V_max=10
        )
        paths.append(pso.optimize(start, end))


    plot_combined(paths, terrain, radars, no_fly_zones, starts, ends)

